# Laserfiche Swagger API

This package is automatically created with Swagger Codegen v3.

You can use this package for API calls against your live Laserfiche Cloud account. 
Visit the [developer center](https://developer.laserfiche.com) for more details.

## laserfiche_api Documentation

The documenation for `laserfiche_api` can be found [on GitHub](https://github.com/Layer8Err/laserfiche_api/blob/main/README.md).

Source code for this package [can be found here](https://github.com/Layer8Err/laserfiche_api/tree/main/laserfiche_api).
